/************************************************************
 * Course      : Operating Systems COP4600                  *
 * Project Name: runway.c    -Porject9                      *
 * Group       : 1                                          *
 * Author      : Anfal Alyousufi                            *
 *               Khaled Alshatti                            *
 *               Abdul Munim Zahid                          *
 * Description : A runway of airplanes at an airport        *
 * Date        : 11th of Nov 2017                           *
 * Finale Project                                           *
 * Dr Korzova                                               *
 * **********************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

//Data structure to represent the different planes used in the thread
typedef struct
{
    int planeID;       //ID of the plane
    pthread_t planeTD; //Thread ID of the plane
}
planes_thread;

//Semaphores
sem_t runwaySemaphore; //The semaphore used for the runway
sem_t queueSemaphore;  //The semaphore used for the gate queue
sem_t queueMutex;      //Auxiliary semaphore, to ensure that 3 planes proceed to the gates

//Method planeLande()

/* The plane must call planeLand to get permission for landing*/
static void planeLand(int planeID){

    printf("[PLANE TO LAND]: Airplane %d requests permission to land\n", planeID);

    sem_wait(&runwaySemaphore);
    printf("[PLANE LANDED]: ===> Airplane %d has landed\n", planeID);
}

/* The plane must call planeQueue to proceed to the gate meanwhile the plane waits on the runway*/
static void planeQueue(int planeID)
{

    int sValue;
    printf("[PLANE TO TAKEOFF]: Airplane %d asks permission to takeoff\n", planeID);
    sem_wait(&queueSemaphore);
    sem_getvalue(&queueSemaphore, &sValue);

    if (sValue != 0)
    {
        sem_wait(&queueMutex);
    }
    else
    {

        sem_post(&queueMutex);
        sem_post(&queueMutex);
    }

    sem_post(&runwaySemaphore);
    printf("[PLANE TAKING OFF]: ===> Airplane %d did proceed to takeoff: %d\n", planeID, 3 - sValue);
    sem_post(&queueSemaphore);
}

//Method planeFunction()
/*The simple thread function, every airplane will try to land after the plane has landed, it proceeds to the gates in queue*/
static void* planeFunction(void* args)
{
   planes_thread* p = (planes_thread*)args;
   planeLand(p->planeID);
   planeQueue(p->planeID);
   return NULL;
}

//Method usage
/*Display usage information on the stderr stream*/
static void usage(char** argv)
{
    fprintf(stderr, "Usage: %s number of planes ...  number of runways\n", argv[0]);
}

//Driver
/*The main function and entry point*/
int main(int argc, char* argv[])
{

    int nVal = 0, mVal = 0, index, tStatus;
    planes_thread* planes;
    if (argc != 3)
    {
        usage(argv);
        exit(EXIT_FAILURE);
    }

   //Assign
    nVal = atoi(argv[1]);
    mVal = atoi(argv[2]);

    if (nVal <= 0 || mVal < 3)
     {
        usage(argv);
        exit(EXIT_FAILURE);
     }
       if (sem_init(&runwaySemaphore, 0, mVal) || sem_init(&queueSemaphore, 0, 3) || sem_init(&queueMutex, 0, 0))
    {
        fprintf(stderr, "%s: initialization of the semaphores failed\n", argv[0]);
        exit(EXIT_FAILURE);
    }
   //Update
   planes = (planes_thread *)calloc(nVal, sizeof(planes_thread));
    if (!planes)
    {
        fprintf(stderr, "%s: out of memory\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    for (index = 0; index < nVal; index++)//loop
     {
       //Update
       planes[index].planeID = index + 1;

       tStatus = pthread_create(&planes[index].planeTD, NULL, planeFunction, (void*)&planes[index]);

     if (tStatus != 0)
     {
        fprintf(stderr, "%s: pthread_create() failure: %d\n", argv[0], tStatus);
      }
    }

    for (index = 0; index < nVal; index++)
    {

        pthread_join( planes[index].planeTD, NULL);
    }

    (void) free(planes);

//Check condition
    if (sem_destroy(&runwaySemaphore) || sem_destroy(&queueSemaphore) || sem_destroy(&queueMutex))
    {

        fprintf(stderr, "%s: destruction of the semaphores failed\n", argv[0]);
        exit(EXIT_FAILURE);
    }


    return EXIT_SUCCESS;
}
