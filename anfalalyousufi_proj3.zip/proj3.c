
/* Anfal AlYousufi */
/* U72884742       */
/* Project 3       */

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <semaphore.h>

#define SLEEP_TIME 1         //sleep time between reads 
#define BUFFER_SIZE 15       //15 positions on buffer
#define SHMKEY ((key_t) 807) //shared memory key
#define _REENTRANT           // Global variable
#define TRUE 1

//Shared Memory Struct
typedef struct
{
      int value;
   }  shared_mem;

// Semaphores Initialization
   sem_t sem1;       //1st Semaphore - Mutex
   sem_t full, empty; // 2nd and 3rd Semaphores 

// Buffer
   shared_mem *counter; // Buffer array
   char buffer[BUFFER_SIZE]; //circular array to be used

// Funtion 
/**********************************************************
 * Producer to read charcters from text file that         * 
 * cointains characthers to be stored in circular array.  *
 **********************************************************/

void* thread1 (void *ptr)
{
    char newChar;  
    FILE* fp;   // Initializing file to be read 
        
    fp = fopen("mytest.dat", "r"); //Opening file mytest.dat
    while (fscanf(fp, "%c", &newChar) != EOF) //Scan and story to the end of the file
   {
        sem_wait(&empty);//Semaphore waiting function

        if (counter->value == BUFFER_SIZE)//if buffer equals 
	 {
            counter->value = 0;
         }
            sem_wait(&sem1); //Critical section
            buffer[counter->value % BUFFER_SIZE] = newChar;    
            counter->value++;
            sem_post(&sem1);
            printf("Producer reads >> %c \n", newChar);
            fflush(stdout);
            sem_post(&full);
	}
    close(fp);  //Closing file after reading the characters 
 
    buffer[counter->value] = '*';
    counter->value++;
    printf("PRODUCER FINISHED\n");


} //Producer finished

/***************************************************************
 * Consumer to consumes the charcters from text file           *
 * that cointains characthers to be stored in circular array.  *
 ***************************************************************/

void* thread2 (void *ptr)
{
    sem_post(&empty);
    char product;
    while (product != '*') //while indicatior not *, meaning last character
    {
        sleep(SLEEP_TIME); //placing second sleep in the consumer thread
        sem_wait(&full);
        if (counter->value > 0)
	{
            sem_wait(&sem1);
            product = buffer[(counter->value - 1)];
            counter->value--;
            sem_post(&sem1);
            printf("Consumer consumed>> %c \n", product);
            fflush(stdout);
        }
        sem_post(&empty);
    }
        printf("CONSUMER  FINISHED\n");

} //consumer finished

/*****************************************************************
 *                           Main                                *
 *                           ****                                */

int main()
{
	int  i;
	int  r=0;
        int shmid; //shared memory ID 

	sem_init(&sem1,0,1);
	sem_init(&full,0,0);

        pthread_t tid1[1];        //process id for thread 1
        pthread_t tid2[1];        // process id for thread 2 
        pthread_attr_t attr[1];   /* attribute pointer array */
    
        char *shmadd;
        shmadd = (char *) 0;

//Create and connect to a shared memory segment
if ((shmid = shmget (SHMKEY, sizeof(int), IPC_CREAT | 0666)) < 0)
    {
        perror ("shmget");
        exit (1);
    }
    if ((counter = (shared_mem *) shmat (shmid, shmadd, 0)) == (shared_mem *) -1)
    {
        perror ("shmat");
        exit (0);
    }
	fflush(stdout);

//Required to schedule thread independently.
    pthread_attr_init(&attr[0]);
    pthread_attr_setscope(&attr[0], PTHREAD_SCOPE_SYSTEM);  
//End to schedule thread independently 

//Create the threads 
    pthread_create(&tid1[0], &attr[0], thread1, NULL);
    pthread_create(&tid2[0], &attr[0], thread2, NULL);

// Wait for the threads to finish 
     pthread_join(tid1[0], NULL);
     pthread_join(tid2[0], NULL);

//destroy the semaphores
     sem_destroy(&empty);
     sem_destroy(&full);
     sem_destroy(&sem1);

//Terminate threads
     //pthread_exit(NULL);

//clean up the memory: detaching memory and cleaing ipc and shared memory that was used
if ((shmctl (shmid, IPC_RMID, (struct shmid_ds *) 0)) == -1)
     {
	perror ("shmctl");
	exit (-1);
      }

//Printing counter value
    printf("From parent counter  =  %d\n", counter->value);
    printf("---------------------------------------------------\n");
    printf("\t\t	End of simulation\n");

    exit(0); //program termination

}//end Main

