/*Anfal AlYousufi
 * U72884742
 * netid: aalyousufi
 * project 1 
 * shared memory
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>

/*key number
  
  #define SHMKEY((pid_t) 1200)
 
*/

void ChildProcess1(int *a);
void ChildProcess2(int *a);
void ChildProcess3(int *a);
void ChildProcess4(int *a);

void main(int argc, char *argv[])
{
     int    shmid;
     int    *total;
     pid_t pid1,pid2,pid3,pid4; /* process identifier */
     int    status;
     char *shmadd;
     shmadd=(char*)0;

     

     shmid = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | 0666);
     if (shmid < 0) {
          printf("shmget error (server)\n");
          exit(1);
     }


     total = (int *) shmat(shmid, NULL, 0);
     if (* total == -1) {
          printf("shmat error (server)\n");
          exit(1);
     }

    *total = 0;

     printf("Server is about to fork a child process...\n");
     pid1 = fork();
     if (pid1 < 0) { /*error occurred */
          printf("*** fork error (server) ***\n");
          exit(1);
     }
     else if (pid1 == 0) {
          ChildProcess1(total);
          exit(0);
     }
    
     pid2 = fork();
     if (pid2 < 0) { /*error occured*/ 
          printf("fork error (server)\n");
          exit(1);
     }
     else if (pid2 == 0) {
          ChildProcess2(total);
          exit(0);
     }
    
     pid3 = fork();
     if (pid3 < 0) { /*error occured*/
          printf("fork error (server)\n");
          exit(1);
     }
     else if (pid3 == 0) {
          ChildProcess3(total);
          exit(0);
     }
    
     pid4 = fork();
     if (pid4 < 0) { /*error occured*/
          printf("fork error (server)\n");
          exit(1);
     }
     else if (pid4 == 0) {
          ChildProcess4(total);
          exit(0);
     }
/*
waitpid(pid1, NULL, 0);
waitpid(pid2, NULL, 0);
waitpid(pid3, NULL, 0);
waitpid(pid4, NULL, 0);

*/
     printf("Child with ID: %d pid has just exited.\n",wait(NULL));
     printf("Child with ID: %d pid has just exited.\n",wait(NULL));
     printf("Child with ID: %d pid has just exited.\n",wait(NULL));
     printf("Child with ID: %d pid has just exited.\n",wait(NULL));

/*     printf("Server has detected the completion of its child...\n");
     shmdt((void *) total);
     printf("Server has detached its shared memory...\n");
     shmctl(shmid, IPC_RMID, NULL);
     printf("Server has removed its shared memory...\n");
     printf("Server exits...\n");
     exit(0);
*/
}

void ChildProcess1(int *a)
{
     /*using for loop*/
     int k =0;
     for (; k<= 100000 ; k++ ) {
     *a= *a+1;
}
     wait(NULL);
     printf("From Process 1: counter = %d\n",*a);
}


void ChildProcess2(int *a)
{
    /* *a = *a + 100000;*/
     int k=0;
     for (; k<= 200000 ; k++ ) {
	*a=*a+1;
     }
     wait(NULL);
     printf("From Process 2: counter = %d\n",*a);
     /*printf("Child with ID: %d has just exited\n",getpid());*/
}
void ChildProcess3(int *a)
{
     /**a = *a + 100000;*/
     int k=0;
     for (; k<= 300000 ; k++ ) {
        *a=*a+1;
}
     wait(NULL);
     printf("From Process 3: counter = %d\n",*a);

}
void ChildProcess4(int *a)
{
   
    /* *a = *a + 100000;*/
     int k=0;
     for (; k<= 500000 ; k++ ) {
        *a=*a+1;
}
     wait(NULL);
     printf("From Process 4: counter = %d\n",*a);

}


