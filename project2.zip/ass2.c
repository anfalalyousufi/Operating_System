/*****************************
 * Anfal AlYousufi           *
 * U72884742                 *
 * Assignment 2 - Semaphores *
 * ***************************/

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>
#include  <sys/sem.h>

//Semaphore key
#define SEMKEY ((key_t) 400L)
//Number of semaphores being created
#define NSEMS 1

//Change the key number
#define SHMKEY ((key_t) 7890)

//GLOBAL
typedef struct
{
  int value;
} shared_mem;

shared_mem *total;


int sem_id, sem_id2; //semaphore id
//semaphore buffers
static struct sembuf OP = {0,-1,0};
static struct sembuf OV = {0,1,0};
struct sembuf *P =&OP;
struct sembuf *V =&OV;

//semaphore union used to generate semaphore
typedef union{
  int val;
  struct semid_ds *buf;
  ushort *array;
} semunion;

//POP (wait()) function for semaphore to protect critical section
int POP()
{
    int status;
    status = semop(sem_id, P,1);
    return status;
}

//VOP (signal()) function for semaphore to release protection
int VOP()
{
  int status;
  status = semop(sem_id, V,1);
  return status;
}



/***********************************************************
 * function increments the value of shared variable "total"
 *  by one with target of 100000
 *----------------------------------------------------------*/

void process1 ()
{
  int k = 0;
 
  while (k < 100000)
    {
        
      POP();
      if (total->value < 1100000) {
        total->value = total->value + 1;
      }
      
      VOP();
      k++;
      
    }
 
  
  printf ("From Process 1: counter = %d\n", total->value);
  
}

/***************************************************************
 * This funtion increments the value of shared variable "total"
 *  by one with target of 200000
 *-------------------------------------------------------------*/

void process2 ()
{
  int k = 0;

  while (k < 200000)
    {

      POP();
      if (total->value < 1100000) {
        total->value = total->value + 1;
      }

      VOP();
      k++;

    }


  printf ("From Process 2: counter = %d\n", total->value);

}
/*----------------------------------------------------------------------*
 * This function increases the vlaue of shared memory variable "total"
 * by one with a target 300000
 *----------------------------------------------------------------------*/
void process3 ()
{
  int k = 0;
  
  while (k < 300000)
  {
    
    POP();
    if (total->value < 1100000) {
      total->value = total->value + 1;
    }
    
    VOP();
    k++;
  }
  
  printf ("From Process 3: counter = %d\n", total->value);
  
}
/*----------------------------------------------------------------------*
 * This function increases the vlaue of shared memory variable "total"
 * by one with a target 500000
 * ---------------------------------------------------------------------*/
void process4 ()
{
  int k = 0;
  
  while (k < 500000)
  {
    
    POP();
    if (total->value < 1100000) {
      total->value = total->value + 1;
    }
    
    VOP();
    k++;
  }
  
  printf ("From Process 4: counter= %d\n", total->value);
  
}

/*----------------------------------------------------------------------*
 *
 * MAIN()
 *----------------------------------------------------------------------*/

int main()
{
  int   shmid;
  int   pid1,pid2,pid3,pid4;
  int   ID;
  int	status;

    
  char *shmadd;
  shmadd = (char *) 0;
  
  //semaphores
  int value, value1;
  int semnum = 0;
  semunion semctl_arg;
  semctl_arg.val =1;

  /* Create semaphores*/
  sem_id = semget(SEMKEY, NSEMS, IPC_CREAT | 0666);
  if(sem_id < 0)
    printf("Error in creating the semaphore./n");
  
  sem_id2 = semget(SEMKEY, NSEMS, IPC_CREAT | 0666);
  if(sem_id2 < 0)
    printf("creating semaphore./n");

  /* Initialize semaphore*/
  value1 =semctl(sem_id, semnum, SETVAL, semctl_arg);
  value =semctl(sem_id, semnum, GETVAL, semctl_arg);
  if (value < 1)
    printf("Error detected in SETVAL./n");

  /* Create and connect to a shared memory segment*/
if ((shmid = shmget (SHMKEY, sizeof(int), IPC_CREAT | 0666)) < 0)
    {
      perror ("shmget");
      exit (1);
    }

 
 if ((total = (shared_mem *) shmat (shmid, shmadd, 0)) == (shared_mem *) -1)
    {
      perror ("shmat");
      exit (0);
    }
  
  
  total->value = 0;

  if ((pid1 = fork()) == 0)
    process1();

  if ((pid1 != 0) && (pid2 = fork()) == 0)
    process2();

  if ((pid1 != 0 ) && (pid2 != 0) && (pid3 = fork()) == 0 )
    process3();

  if ((pid1 != 0 ) && (pid2 != 0) && (pid3!=0) && (pid4=fork()) == 0 )
    process4();

  
  
  waitpid(pid1, NULL, 0 );
  waitpid(pid2, NULL, 0 );
  waitpid(pid3, NULL, 0 );
  waitpid(pid4, NULL, 0 );
 
  if ((pid1 != 0) && (pid2 != 0) && (pid3 != 0) && (pid4 !=0 ))   

	{
	             
        printf("Child with ID: %d has exited.\n", pid1);
        
        waitpid(pid2);
        
        printf("Child with ID: %d has exited.\n", pid2);
        
        waitpid(pid3);
        
        printf("Child with ID: %d has exited.\n", pid3);
        
        waitpid(pid4);
        
	printf("Child with ID: %d has exited.\n\n", pid4);
        
        

      if ((shmctl (shmid, IPC_RMID, (struct shmid_ds *) 0)) == -1)
	{
	  perror ("shmctl");
	  exit (-1);
	}
      
      printf ("\t\t  End of Program\n");


    
/* De-allocate semaphore */
      semctl_arg.val = 0;
      status =semctl(sem_id, 0, IPC_RMID, semctl_arg);
      if( status < 0)
        printf("Error in removing the semaphore.\n");
    }
  
} 
